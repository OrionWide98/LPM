/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package testapagamento;

/**
 *
 * @author franc
 */
public class TestaPagamento {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        CartaoCredito cr = new CartaoCredito();
        Dinheiro d = new Dinheiro();
        Cheque ch = new Cheque();
        
    }
    
}
