/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package aula_interface;

/**
 *
 * @author franc
 */
public interface VeiculoTerrestre {
    
    public void virarEsquerda();
    
    public void virarDireita();
    
    public void acelerar();
    
    
}
