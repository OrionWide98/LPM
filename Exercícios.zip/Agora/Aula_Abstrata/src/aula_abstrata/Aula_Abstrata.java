/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package aula_abstrata;

/**
 *
 * @author franc
 */
public class Aula_Abstrata {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        //Pessoa a = new Pessoa();
        
        Aluno al = new Aluno();
        al.mostraDados();
        al.testaDados();
        
        Professor prof = new Professor();
        prof.mostraDados();
        prof.testaDados();
        
        Pessoa p1 = new Aluno();
        p1.mostraDados();
        p1.testaDados();
    }
    
}
