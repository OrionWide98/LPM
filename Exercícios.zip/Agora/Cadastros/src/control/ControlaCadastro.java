/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package control;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import model.Pessoa;
import model.Produto;

/**
 *
 * @author franc
 */
public class ControlaCadastro {
    private ArrayList pessoa;
    private ArrayList produto;
    
    
    //Singleton
    private static ControlaCadastro controlaInstancia = null;
    
    
    public ControlaCadastro()
    {
        pessoa = new ArrayList();
        produto = new ArrayList();
    }
    
    public static ControlaCadastro getInstancia()
    {
        if(controlaInstancia == null)
        {
            controlaInstancia = new ControlaCadastro();
        }
        return controlaInstancia;
    }
    
    //Formulário Pessoas
    
    public Pessoa cadastraPessoa(String nome, String turma)
    {
        Pessoa pp = new Pessoa();
        
        pp.setNome(nome);
        pp.setTurma(turma);
        
        pessoa.add(pp);
        
        return pp;
    }
    
    public Pessoa cadastraPessoa(String nome, String turma, int index)
    {
        Pessoa pp = new Pessoa();
        
        pp.setNome(nome);
        pp.setTurma(turma);
        
        pessoa.add(index,pp);
        
        return pp;
    }
    
    public Pessoa escrevePessoa()
    {
        Pessoa p = new Pessoa();
        
        Iterator person = pessoa.iterator();
        
        while(person.hasNext())
        {
            Pessoa p1 = (Pessoa) person.next();
            p = p1;
        }
        
        return p;
    }
    
    public void removePessoa(String conp)
    {
        
        Iterator person = pessoa.iterator();
        
        while(person.hasNext())
        {
            Pessoa per = (Pessoa) person.next();
            if(conp.equals(per.getNome()) || (conp.equals(per.getTurma())))
            {
                pessoa.remove(per);
                break;
            }
        }   
    }
    
    //Formulário Produtos
    
    public Produto cadastraProduto(String nome, String valor, String quantidade)
    {
        Produto pr = new Produto();
        
        pr.setNome(nome);
        pr.setQuantidade(quantidade);
        pr.setValor(valor);
        
        produto.add(pr);
        
        return pr;
    }
    
    public Produto escreveProduto()
    {
        Produto p = new Produto();
        Iterator prod = produto.iterator();
        
        while(prod.hasNext())
        {
            Produto p1 = (Produto) prod.next();
            p = p1;
        }
        
        return p;
    }
    
    public void removeProduto(String conp)
    {
        
        Iterator prod = produto.iterator();
        
        while(prod.hasNext())
        {
            Produto per = (Produto) prod.next();
            if(conp.equals(per.getNome()) || conp.equals(per.getQuantidade()) || conp.equals(per.getValor()))
            {
                produto.remove(per);
                break;
            }
        }   
    }
}
