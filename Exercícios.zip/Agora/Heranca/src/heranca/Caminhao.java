/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package heranca;

/**
 *
 * @author franc
 */
public class Caminhao extends Veiculo_Terrestre{
    private int qntCarga;
    
    public int getQntcarga() {
        return qntCarga;
    }

    public void setQntCarga(int qnt) {
        this.qntCarga = qnt;
    }
    
    public Caminhao(){
        super();
        qntCarga = 0;
    }
}
