/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package heranca;

/**
 *
 * @author franc
 */
public class Passeio extends Veiculo_Terrestre{
    private int porta_malas;
    
    public int getPortaMalas() {
        return porta_malas;
    }

    public void setPortaMalas(int pm) {
        porta_malas = pm;
    }
    
    public Passeio(){
        super();
        porta_malas = 0;
    }
}
