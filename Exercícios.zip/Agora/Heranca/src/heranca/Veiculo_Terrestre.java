/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package heranca;

/**
 *
 * @author franc
 */
public class Veiculo_Terrestre {
    protected int numeroRodas;
    protected String marca;
    protected int km;
    protected int placa;
    protected boolean estado;
    
    public int getNumeroRodas() {
        return numeroRodas;
    }

    public void setNumeroRodas(int numeroRodas) {
        this.numeroRodas = numeroRodas;
    }

    public String getMarca() {
        return marca;
    }

    public void setMarca(String marca) {
        this.marca = marca;
    }

    public int getKm() {
        return km;
    }

    public void setKm(int km) {
        this.km = km;
    }

    public int getPlaca() {
        return placa;
    }

    public void setPlaca(int placa) {
        this.placa = placa;
    }

    public boolean isEstado() {
        return estado;
    }

    public void setEstado(boolean estado) {
        this.estado = estado;
    }
    
    public Veiculo_Terrestre(){
        numeroRodas = 0;
        marca = "";
        km = 0;
        placa = 0;
        estado = false;
    }
    
    public void ligaCarro(){
        setEstado(true);
    }
    public void desligaCarro(){
        setEstado(false);
    }
    public void acelera(){
        if(isEstado() == false){
            System.out.println("Carro Desligado");
        } else{
            System.out.println("Vruuuum!!!");
        }
    }
}
