/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package heranca;

/**
 *
 * @author franc
 */
public class Moto extends Veiculo_Terrestre{
    private String guidao;
    
    public String getGuidao() {
        return guidao;
    }

    public void setGuidao(String guidao) {
        this.guidao = guidao;
    }
    
    public Moto(){
        super();
        guidao = "";
    }
}
