/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package xadrez;

import java.util.Scanner;

/**
 *
 * @author franc
 */
public class Xadrez {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        int l;
        int c;
        Scanner input = new Scanner(System.in);
        
        System.out.print("Digite o número de linhas: ");
        l = input.nextInt();
        
        System.out.print("Digite o número de colunas: ");
        c = input.nextInt();
        
        if((l>=1 && l <=1000) && (c>=1 && c<=1000))
        {
            if(l >= c)
            {
                if((l-c)%2 == 0)
                {
                    System.out.println("1");
                }
                else System.out.println("0");

            }

            if(c > l)
            {
                if((c-l)%2 == 0)
                {
                    System.out.println("1");
                }
                else System.out.println("0");
            }
        }
        else System.out.println("Valor fora do limite (entre 1 e 1000)");
    }
    
}
