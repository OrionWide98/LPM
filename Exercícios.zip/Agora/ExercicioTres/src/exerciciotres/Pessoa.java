/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package exerciciotres;

import java.util.GregorianCalendar;

/**
 *
 * @author aluno
 */
public class Pessoa {
    GregorianCalendar calendar = new GregorianCalendar();
    private int idade;
    private int dia;
    private int mes;
    private int ano;
    private String nome;
    
    //Construtor
    public Pessoa(){
        dia = 1;
        mes = 1;
        ano = 1990;
    }
    
    public Pessoa(int d,int m, int a){
        dia = d;
        mes = m;
        ano = a;
    }
    
    //Gets e Sets
    public int getDia() {
        return dia;
    }

    public void setDia(int dia) {
        this.dia = dia;
    }

    public int getMes() {
        return mes;
    }

    public void setMes(int mes) {
        this.mes = mes;
    }

    public int getAno() {
        return ano;
    }

    public void setAno(int ano) {
        this.ano = ano;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }
    
    public int getIdade(){
        return idade;
    }
    //Métodos
    
    //Métodos de validação
    public void validaDia(){
        if((dia<1) || (dia>31)){
            dia = 1;
        }
    }
    
    public void validaMes(){
        if((mes<1) || (mes>12)){
            mes = 1;
        }
    }
    
    public void validaAno(){
        int year = calendar.get(GregorianCalendar.YEAR);
        if ((ano<1000) || (ano>year)){
            ano = 1990;
        }
    }
    
    public void calculaIdade(){
        int day= calendar.get(GregorianCalendar.DAY_OF_MONTH);
        int mouth = calendar.get(GregorianCalendar.MONTH);
        int year = calendar.get(GregorianCalendar.YEAR);
        idade = year - ano;
        if(mouth<mes){
            idade -= 1;
        } else {
            if((mouth == mes) && (day > dia)){
                idade -=1;
            }
        }
    }
    
    public String informaNome(){
        return nome;
    }
    
}
