/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package exerciciotres;

/**
 *
 * @author aluno
 */
public class ExercicioTres {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        System.out.println("A data padrão é 01/01/1990.Qual valor informado errado fará retornar para o padrão de cada variável");
        Pessoa genio1 = new Pessoa();
        Pessoa genio2 = new Pessoa();
        
        //Isaac Newton
        genio1.setNome("Isaac Newton");
        genio1.setDia(4);
        genio1.setMes(1);
        genio1.setAno(1643);
        
        //Validação
        genio1.validaDia();
        genio1.validaMes();
        genio1.validaAno();
        
        genio1.calculaIdade();
        System.out.println(genio1.informaNome() + " teria " + genio1.getIdade() + " anos de idade se estivesse vivo.");
        
        //Albert Einstein
        genio2.setNome("Albert Einstein");
        genio2.setDia(14);
        genio2.setMes(3);
        genio2.setAno(1879);
        
        //Validação
        genio2.validaDia();
        genio2.validaMes();
        genio2.validaAno();
        
        genio2.calculaIdade();
        System.out.println(genio2.getIdade());
    }
    
}
