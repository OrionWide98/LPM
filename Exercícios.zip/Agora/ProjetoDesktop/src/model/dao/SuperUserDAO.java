/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model.dao;

import connection.Conexao;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import model.bean.SuperUser;

/**
 *
 * @author franc
 */
public class SuperUserDAO {
    
    Connection con = null;
    
    public boolean inserir(SuperUser su) throws SQLException
    {
        boolean inseriu = false;
        try
        {
            con = new Conexao().getConnection();
            String sql = "INSERT INTO user (userName, senha, permicao) VALUES (?, ?, ?)";
            PreparedStatement stmt = con.prepareStatement(sql);
            stmt.setString(1, su.getNome());
            stmt.setString(2, su.getSenha());
            stmt.setInt(3, SuperUser.getPermicao());
            stmt.execute();
            stmt.close();
            inseriu = true;
        } catch (Exception ex)
        {
            ex.printStackTrace();
        }
        finally
        {
            con.close();
        }
        return inseriu;
    }
    
    public ArrayList<SuperUser> busca() throws SQLException, ClassNotFoundException{
        ResultSet rs = null;
        
        ArrayList<SuperUser> lista = new ArrayList<SuperUser>();
        
        try{
            con = new Conexao().getConnection();
            String sql = "SELECT * FROM user";
            PreparedStatement stmt = con.prepareStatement(sql);
            rs = stmt.executeQuery();
            
            while (rs.next()){
                SuperUser su = new SuperUser();
                su.setNome(rs.getString("nome"));
                su.setSenha(sql);
            }
            
        }
        catch (Exception ex){
            
        }
        return null;
    }
}
