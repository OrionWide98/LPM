/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hospital;

/**
 *
 * @author franc
 */
public class Cirurgiao extends Medico{
    @Override
    public void tratarPaciente(){
        System.out.println("BISTURIIIIIIIIII");
    }
    
    public void fazerIncisao(){
        System.out.println("KATCHAAAAAAAAAAAAAAAAAAAUUUU");
    }
}
