/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package control;

import java.util.ArrayList;
import java.util.Iterator;
import model.Pessoa;

/**
 *
 * @author franc
 */
public class ControlaCadastros {
    private ArrayList pessoa;
    public static ControlaCadastros controle = null;
    
    public Pessoa cadastraPessoa(String nome, String ra, String turma)
    {
        Pessoa p = new Pessoa();
        p.setNome(nome);
        p.setRa(ra);
        p.setTurma(turma);
        
        pessoa.add(p);
        
        return p;
    }
    
    public static ControlaCadastros getInstancia()
    {
        if(controle == null)
        {
            controle = new ControlaCadastros();
        }
        return controle;
    }
    
    public Pessoa escreveAluno()
    {
        Pessoa a = new Pessoa();
        Iterator pe = pessoa.iterator();
        while(pe.hasNext())
        {
            Pessoa pp = (Pessoa) pe.next();
            a = pp;
        }
        
        return a;
    }
    
}
