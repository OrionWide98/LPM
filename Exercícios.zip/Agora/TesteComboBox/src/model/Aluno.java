/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

/**
 *
 * @author franc
 */
public class Aluno {
    private String nome;
    private String ra;
    private String linguagem;
    
    public Aluno(String n, String r, String l)
    {
        nome = n;
        ra = r;
        linguagem = l;
    }
}
