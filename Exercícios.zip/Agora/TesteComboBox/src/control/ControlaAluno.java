/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package control;

import java.util.ArrayList;
import model.Aluno;

/**
 *
 * @author franc
 */
public class ControlaAluno {
    private ArrayList alunos;
    
    public ControlaAluno()
    {
        alunos = new ArrayList();
    }
    
    public void adicionaAluno(String nome, String ra, String linguagem)
    {
        Aluno a1 = new Aluno(nome, ra, linguagem);
        
        alunos.add(a1);
    }
}
