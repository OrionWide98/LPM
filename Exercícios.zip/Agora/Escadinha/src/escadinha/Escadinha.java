/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package escadinha;

import java.util.ArrayList;
import java.util.Scanner;

/**
 *
 * @author franc
 */
public class Escadinha {

    public void testaSequencia(ArrayList seq,int nSeq)
    {
        
    }
    
    public static void main(String[] args) {
        ArrayList sequencia = new ArrayList();
        int temp;
        int nSeq, a=0;
        
        Scanner input = new Scanner(System.in);
        
        System.out.print("Digite a quantidade de termos da sequencia: ");
        nSeq = input.nextInt();
        
        if(nSeq>=1 && nSeq<=100)
        {
            while(a<nSeq)
            {
                System.out.print("Digite um número inteiro para a sequência: ");
                temp = input.nextInt();
                System.out.println("Número digitado: " + temp);
                
                
                if(temp < (-1000000) || temp > 1000000 )
                {
                    System.out.println("Número fora do limite!");
                    a--;
                }
                else sequencia.add(temp);
                a++;
            }            
        }
        else System.out.println("Número de termos fora do limite!");
    }
}
