/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package testearray;

/**
 *
 * @author franc
 */
public class Produto {
    
    public void mostradados()
    {
        System.out.println("Produto");
    }
}
