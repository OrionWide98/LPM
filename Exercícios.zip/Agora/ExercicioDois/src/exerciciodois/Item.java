/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package exerciciodois;

/**
 *
 * @author aluno
 */
public class Item {
    //Atributos
    private String codigo;
    private String desc;
    private int quantidade;
    private float preco;
    
    //Gets e Sets
    public String getCodigo() {
        return codigo;
    }

    public void setCodigo(String codigo) {
        this.codigo = codigo;
    }

    public String getDesc() {
        return desc;
    }

    public void setDesc(String desc) {
        this.desc = desc;
    }

    public int getQuantidade() {
        return quantidade;
    }

    public void setQuantidade(int quantidade) {
        this.quantidade = quantidade;
    }

    public float getPreco() {
        return preco;
    }
    
    public void setPreco(float preco) {
        this.preco = preco;
    }
    
    //Construtor Default
    public Item(){
        codigo = " ";
        desc = " ";
        quantidade = 0;
        preco = 0;
    }
    
    //Método
    public float GetTotal(){
        float tot;
        if (quantidade < 0){
            quantidade = 0;
        }
        if (preco < 0){
            preco = 0;
        }
        
        tot = quantidade * preco;
        return tot;
    }
    
    
}
