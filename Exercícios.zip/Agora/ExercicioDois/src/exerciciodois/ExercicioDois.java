/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package exerciciodois;

/**
 *
 * @author aluno
 */
public class ExercicioDois {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        float total;
        Item caderno = new Item();
        Item lapis = new Item();
        Item borracha = new Item();
        
        caderno.setCodigo("1526");
        caderno.setDesc("Caderno 20 matérias");
        caderno.setQuantidade(2);
        caderno.setPreco(15.00f);
        System.out.printf("Código do Produto: %s\n",caderno.getCodigo());
        System.out.printf("Descrição: %s\n", caderno.getDesc());
        System.out.printf("Quantidade: %d\n", caderno.getQuantidade());
        System.out.printf("Preço: R$%.2f\n", caderno.getPreco());
        total = caderno.GetTotal();
        System.out.printf("Total da Compra: R$%.2f\n", total);
        
        System.out.println("Lápis");
        System.out.print(lapis.getCodigo());
        System.out.print(lapis.getDesc());
        System.out.print(lapis.getPreco());
        System.out.print(lapis.getQuantidade());
        
        System.out.println("");
        
        System.out.println("Borracha");
        borracha.setPreco(5);
        borracha.setQuantidade(-6);
        borracha.GetTotal();
        System.out.println(borracha.getQuantidade());
        System.out.println(borracha.getPreco());
    }
    
}
