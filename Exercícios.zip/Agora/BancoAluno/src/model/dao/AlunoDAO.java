/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model.dao;

import connection.Conexao;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import model.bean.Aluno;

/**
 *
 * @author franc
 */
public class AlunoDAO {
    Connection con = null;
    
    public boolean inserir(Aluno al) throws SQLException, ClassNotFoundException{
        boolean  inseriu = false;
        
        if(al.getStatus() == "Selecione"){
            al.setStatus("Recuperacao");
        }
        
        try{
           con = new Conexao().getConnection();
           String sql = "INSERT INTO aluno (ra,nome,status) VALUES (?,?,?)";
           PreparedStatement stmt = con.prepareStatement(sql);
           stmt.setInt(1, al.getRa());
           stmt.setString(2, al.getNome());
           stmt.setString(3, al.getStatus());
           stmt.execute();
           stmt.close();
           inseriu = true;
        } catch (Exception ex){
            ex.printStackTrace();
        }
        finally{
            con.close();
        }
        return inseriu;
    }
    
    public boolean exclui(Aluno al) throws SQLException, ClassNotFoundException{
        boolean exclui = false;
        
        try{
            con = new Conexao().getConnection();
            String sql = "DELETE FROM aluno WHERE ra = ?";
            PreparedStatement stmt = con.prepareStatement(sql);
            stmt.setInt(1,al.getRa());
            stmt.execute();
            stmt.close();
            exclui = true;
        } catch (Exception ex){
            ex.printStackTrace();
        }
        finally{
            con.close();
        }
        
        return exclui;
    }
    
    public ArrayList<Aluno> buscar() throws SQLException, ClassNotFoundException{
        ResultSet rs = null;
        ArrayList<Aluno> listaAlunos = new ArrayList<Aluno>();
        try{
            con = new Conexao().getConnection();
            
            String sql = "SELECT * FROM aluno ";
            PreparedStatement stmt = con.prepareStatement(sql);
            rs = stmt.executeQuery();
            
            while(rs.next())
            {
                Aluno al = new Aluno();
                al.setRa(rs.getInt("ra"));
                al.setNome(rs.getString("nome"));
                al.setStatus(rs.getString("status"));
                listaAlunos.add(al);
            }
            stmt.close();
        } catch (Exception ex){
            ex.printStackTrace();
        }
        finally{
            con.close();
        }
        return listaAlunos;
    }
    
}