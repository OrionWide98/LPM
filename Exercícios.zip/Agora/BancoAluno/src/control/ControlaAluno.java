/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package control;

import java.sql.SQLException;
import java.util.ArrayList;
import model.bean.Aluno;
import model.dao.AlunoDAO;

/**
 *
 * @author franc
 */
public class ControlaAluno {
    public boolean insereAluno(int ra,  String nome, String stt) throws SQLException, ClassNotFoundException{
        Aluno al = new Aluno (ra, nome, stt);
        AlunoDAO alDAO = new AlunoDAO();
        boolean inseriu = alDAO.inserir(al);
        return inseriu;
    }
    
    public boolean excluiAluno(int ra, String nome, String stt) throws SQLException, ClassNotFoundException{
        Aluno al = new Aluno(ra,nome, stt);
        AlunoDAO alDAO = new AlunoDAO();
        
        boolean excluiu = alDAO.exclui(al);
        return excluiu;
    }
    
    public ArrayList<Aluno> buscarAluno() throws SQLException, ClassNotFoundException{
        AlunoDAO alDAO = new AlunoDAO();
        return(alDAO.buscar());
    }
}
