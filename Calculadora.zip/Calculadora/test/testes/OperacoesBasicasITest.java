/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package testes;

import OperacoesBasicas.OperacoesBasicas;
import org.junit.Test;
import static org.junit.Assert.*;
import org.junit.Before;

/**
 *
 * @author aluno
 */
public class OperacoesBasicasITest {
    
    OperacoesBasicas a = new OperacoesBasicas();
    int num;
    public OperacoesBasicasITest() {
    }
    
    @Before
    public void setUp(){
        num = 10;
    }

    @Test
    public void testaSoma(){
        assertEquals(num, a.soma(2, 8));
    }
    
    @Test
    public void testaSub(){
        assertEquals(num, a.sub(12, 2));
    }
    
    @Test
    public void testaMult(){
        assertEquals(num, a.multi(5, 2));
    }
    
    @Test(expected=ArithmeticException.class)
    public void testaDiv(){
        assertEquals(num, a.div(50, 0), 0);
    }
}
