/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package testes;

import OperacoesBasicas.OperacoesBasicas;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author aluno
 */
public class OperacoesBasicasIITest {
    
    OperacoesBasicas a = new OperacoesBasicas();
    
    public OperacoesBasicasIITest() {
    }

    @Test
    public void testaPotencia(){
        assertEquals(25, a.potencia(5, 2));
    }
    
    @Test(expected = ArithmeticException.class)
    public void testaRaizQ(){
        assertEquals(5, a.raizQ(25, 0), 0);
    }
}
