/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package OperacoesBasicas;

/**
 *
 * @author aluno
 */
public class OperacoesBasicas {
    
    public int soma(int a, int b){
        return a+b;
    }
    
    public int multi(int a, int b){
        return a*b;
    }
    
    public int sub(int a, int b){
        return a-b;
    }
    
    public float div(int a, int b){
        if(b==0){
            throw new ArithmeticException();
        }
        return a/b;
    }
    
    public int potencia(int a, int b){
        return (int) Math.pow(a, b);
    }
    
    public float raizQ(int a, int b){
        if(b<0 || b == 0){
            throw new ArithmeticException();
        }
        return (float) Math.pow(a, (1/b));
    }
    
}
