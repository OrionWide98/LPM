/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package control;

import java.sql.SQLException;
import model.bean.Produto;
import model.dao.ProdutoDAO;

/**
 *
 * @author aluno
 */
public class ControlaProduto {
    public boolean insereProduto(String codigo, float preco, float peso, String desc) throws ClassNotFoundException, SQLException{
        Produto p = new Produto(codigo, preco, peso, desc);
        ProdutoDAO pdao = new ProdutoDAO();
        boolean inseriu = pdao.insereProduto(p);
        return inseriu;
    }
}
