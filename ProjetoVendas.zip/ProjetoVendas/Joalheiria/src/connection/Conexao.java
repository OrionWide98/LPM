/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package connection;

import com.mysql.jdbc.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

/**
 *
 * @author aluno
 */
public class Conexao {
    
    public Connection getConnection() throws ClassNotFoundException, SQLException{
        String driver = "com.mysql.jdbc.Driver";
        String url = "jdbc:mysql://143.106.241.1:3306/cl18464";
        String user = "cl18464";
        String senha = "cl*22082002";
        try{
            Class.forName(driver);
            return (Connection) DriverManager.getConnection(url,user,senha);
        } catch(SQLException ex){
            throw new RuntimeException("Erro de Conexão", ex);
        }
    }
    
}
