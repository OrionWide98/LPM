/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model.bean;

/**
 *
 * @author aluno
 */
public class Produto {
    
    private String codigo;
    private float precoU;
    private float pesoU;
    private String descr;
    
    public Produto(){
        
    }
    
    public Produto(String cod, float preco, float peso, String desc){
        codigo = cod;
        precoU = preco;
        pesoU = peso;
        descr = desc;
    }
    
    public String getCodigo() {
        return codigo;
    }

    public void setCodigo(String codigo) {
        this.codigo = codigo;
    }

    public float getPrecoU() {
        return precoU;
    }

    public void setPrecoU(float precoU) {
        this.precoU = precoU;
    }

    public float getPesoU() {
        return pesoU;
    }

    public void setPesoU(float pesoU) {
        this.pesoU = pesoU;
    }

    public String getDescr() {
        return descr;
    }

    public void setDescr(String descr) {
        this.descr = descr;
    }
}
