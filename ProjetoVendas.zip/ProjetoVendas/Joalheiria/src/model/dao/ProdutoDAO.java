/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model.dao;

import connection.Conexao;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import model.bean.Produto;

/**
 *
 * @author aluno
 */
public class ProdutoDAO {
    private Connection con = null;
    
    public boolean insereProduto(Produto p) throws ClassNotFoundException, SQLException{
        boolean insere = false;
        try{
            con = new Conexao().getConnection();
            String sql = "insert into produto values (?,?,?,?)";
            PreparedStatement stmt = con.prepareStatement(sql);
            stmt.setString(1, p.getCodigo());
            stmt.setFloat(2, p.getPrecoU());
            stmt.setFloat(3, p.getPesoU());
            stmt.setString(4, p.getDescr());
            
            stmt.execute();
            stmt.close();
            insere = true;
        }
        catch (Exception ex){
            ex.printStackTrace();
        }
        finally{
            con.close();
        }
        return insere;
    }
}
