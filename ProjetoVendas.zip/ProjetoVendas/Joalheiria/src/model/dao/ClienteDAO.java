/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model.dao;

import connection.Conexao;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import model.bean.Cliente;

/**
 *
 * @author aluno
 */
public class ClienteDAO {
    
    private Connection con = null;
    
    public boolean insereCliente(Cliente cli) throws ClassNotFoundException, SQLException{
        boolean inseriu = false;
        
        try{
            con = new Conexao().getConnection();
            String sql = "insert into cliente values (?,?,?,?,?,?,?,?,?,?,?)";
            PreparedStatement stmt = con.prepareStatement(sql);
            stmt.setString(1, cli.getCpf());
            stmt.setString(2, cli.getNome());
            stmt.setString(3, cli.getRua());
            stmt.setString(4, cli.getNum());
            stmt.setString(5, cli.getBairro());
            stmt.setString(6, cli.getCidade());
            stmt.setString(7, cli.getEstado());
            stmt.setString(8, cli.getCep());
            stmt.setString(9, cli.getTel1());
            stmt.setString(10, cli.getTel2());
            stmt.setString(11, cli.getEmail());
            
            stmt.execute();
            stmt.close();
            inseriu = true;
        } catch(Exception ex){
            ex.printStackTrace();
        }
        finally{
            con.close();
        }
        return inseriu;
    }
}
