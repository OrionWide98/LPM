/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package aulainterface;

/**
 *
 * @author aluno
 */
public class AulaInterface {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Ferrari fvermelha = new Ferrari();
        fvermelha.acelerar();
        double preco = fvermelha.getPreco();
        System.out.println("A ferrari custa" + preco);
        
        Fusca fuscaAzul = new Fusca();
        fuscaAzul.virarEsquerda();
        fuscaAzul.abrirPorta();
        double precoF = fuscaAzul.getPreco();
        System.out.println("O fusca custa" + precoF);
                
    }
    
}
