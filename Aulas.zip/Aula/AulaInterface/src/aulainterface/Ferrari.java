/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package aulainterface;

/**
 *
 * @author aluno
 */
public class Ferrari implements Carro, ItemCaro{

    @Override
    public void abrirPorta() {
        System.out.println("Ferrari abriu a porta");
    }

    @Override
    public void virarEsquerda() {
        System.out.println("Ferrari vira a esquerda");
    }

    @Override
    public void virarDireita() {
        System.out.println("Ferrari vira a direita");
    }

    @Override
    public void acelerar() {
        System.out.println("Ferrari acelerou");
    }

    @Override
    public double getPreco() {
       return(1500000);
    }
    
}
