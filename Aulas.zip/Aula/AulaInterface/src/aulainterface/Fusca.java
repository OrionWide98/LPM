/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package aulainterface;

/**
 *
 * @author aluno
 */
public class Fusca implements Carro, ItemCaro {

    @Override
    public void abrirPorta() {
        System.out.println("Fusca abriu a porta");
        System.out.println("Esse fusca é novo");
    }

    @Override
    public void virarEsquerda() {
        System.out.println("Fusca virou à esquerda");
        System.out.println("Esse fusca é flex");
    }

    @Override
    public void virarDireita() {
        System.out.println("Fusca Virou à direita");
        System.out.println("Fusca conversível");
    }

    @Override
    public void acelerar() {
        System.out.println("Fusca Acelerou");
        System.out.println("Fusca perdeu o motor");
    }

    @Override
    public double getPreco() {
        double imposto = 500;
        return(76000+imposto);
    }
    
}
