/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package aulascotil;

/**
 *
 * @author aluno
 */
public class Disciplina {
    private String nome;
    private String professor;
    private String coordenador;
    private int duracao;
    private int alunos=0;
    
    //metodos
    
    public String getNome() {
        return nome;
    }
    
    public void setNome(String nome) {
        this.nome = nome;
    }
    
    public String getProf() {
        return professor;
    }
    
    public void setProf(String prof) {
        professor = prof;
    }
    
    public String getCoor() {
        return coordenador;
    }
    
    public void setCoor(String coor) {
        coordenador = coor;
    }
    
    public int getDur() {
        return duracao;
    }
    
    public void setDur(int dur) {
        duracao = dur;
    }
    
    public int getAluno() {
        return alunos;
    }
    
    public void setAluno(int al) {
        alunos = al;
    }
    
    public void quantidade(){
        if (alunos>=40){
            System.out.println("Quantidade máxima de alunos atingida");
        }
        else{ 
            System.out.println("Aluno cadastrado");
            alunos++; 
        }
    }
    
  
}
