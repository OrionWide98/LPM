/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package aulascotil;

import java.util.Scanner;

/**
 *
 * @author aluno
 */
public class Aluno {
    //Atributos
    private String nome;
    private String ra = "";
    private String curso = "n";
    private String turno;
    private String turma;
    private boolean presenca;
    
    //Metodos
    
    public String getNome() {
        return nome;
    }
    
    public String getRa() {
        return ra;
    }
    
    public String getCurso() {
        return curso;
    }
    
    public String getTurno() {
        return turno;
    }
    
    public String getTurma() {
        return turma;
    }
    
    public boolean getPresenca() {
        return presenca;
    }
    
    public void setNome(String nome) {
        this.nome = nome;
    }
    
    public void setRa(String ra) {
        this.ra = ra;
    }
    
    public void setCurso(String curso) {
        this.curso = curso;
    }
    
    public void setTurno(String turno) {
        this.turno = turno;
    }
    
    public void setTurma(String turma) {
        this.turma = turma;
    }
    
    public void setPresenca(boolean presenca) {
        this.presenca = presenca;
    }
    
    
    public void matricula() {
        Scanner input = new Scanner(System.in);
        if ("n".equals(curso)) {
            System.out.println("Curso desejado: ");
            curso = input.nextLine();
        }
        else {
            System.out.println("Você já está matrículado.");
        }
    }
    
    public void palestra() {
        if (ra == "") {
            System.out.println("Não pode acessar a palestra");
        }
    }
    
    public void presente() {
        if (presenca) {
            System.out.println("O aluno está presente");
        }
    }
    
}
