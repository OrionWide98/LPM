/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package aulascotil;

/**
 *
 * @author aluno
 */
public class AulasCotil {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Aluno a = new Aluno();
        
        a.setNome("Clayton");
        a.setRa("18457");
        a.setCurso("Informatica");
        a.setTurno("Noite");
        a.setTurma("2cti");
        a.setPresenca(true);
        
        String n = a.getNome();
        String ra = a.getRa();
        String cur = a.getCurso();
        String tur = a.getTurno();
        String tm = a.getTurma();
        boolean p = a.getPresenca();
        
        a.presente();
        
        Disciplina b = new Disciplina();
        
        b.setNome("Informática");
        b.setProf("Rosana");
        b.setCoor("Elaine");
        b.setDur(2);
        b.setAluno(30);
        
        b.quantidade();
    }
    
}
