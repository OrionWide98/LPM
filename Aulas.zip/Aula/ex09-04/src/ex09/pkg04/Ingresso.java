/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ex09.pkg04;

/**
 *
 * @author aluno
 */
public class Ingresso {
 private float valor;
 
     /**
     * @return the valor
     */
    public float getValor() {
        return valor;
    }

  public Ingresso(float v)
  {
      valor = v;
  }
   
    


public void imprimeValor()
{
    System.out.printf("Valor do Ingresso R$%.2f",valor);
}

}