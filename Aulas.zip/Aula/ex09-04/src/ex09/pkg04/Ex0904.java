/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ex09.pkg04;

import java.util.ArrayList;
import java.util.Iterator;
/**
 *
 * @author aluno
 */
public class Ex0904 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        float soma=0;
        ArrayList <Ingresso> lista = new ArrayList();
    vip v1 = new vip(5.90f,.20f);
    vip v2 = new vip(5.90f,.40f);
    vip v3 = new vip(5.90f,.10f);
    vip v4 = new vip(5.90f,2.00f);
    vip v5 = new vip(5.90f,1.90f);
    
    
    lista.add(v1);
    lista.add(v2);
    lista.add(v3);
    lista.add(v4);
    lista.add(v5);
    
    
    Comum c1 = new Comum(5.70f);
    Comum c2 = new Comum(4.98f);
    Comum c3 = new Comum(6.20f);
    Comum c4 = new Comum(10.00f);
    Comum c5 = new Comum(15.15f);
    
    lista.add(c1);
    lista.add(c2);
    lista.add(c3);
    lista.add(c4);
    lista.add(c5);
    
        Iterator <Ingresso> cat = lista.iterator();
        
        
        while(cat.hasNext())
        {
            Ingresso fat = cat.next();
            
            soma += fat.getValor();
        }
        System.out.println("Faturamento total: R$2.f\n",soma);
    }
    
}
