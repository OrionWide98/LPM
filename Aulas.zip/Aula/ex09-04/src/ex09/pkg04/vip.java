/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ex09.pkg04;

/**
 *
 * @author aluno
 */
public class vip extends Ingresso{
    private final float valorAd;
     public vip(float v, float vA){
         super(v);
         valorAd  = vA;
     }
    @Override
    public void imprimeValor()
    {
        System.out.printf("Valor Ingresso VIP: R$%2.f",(getValor() + valorAd));
    }
    
}
