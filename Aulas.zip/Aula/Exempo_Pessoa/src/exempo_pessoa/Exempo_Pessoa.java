/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package exempo_pessoa;

/**
 *
 * @author aluno
 */
public class Exempo_Pessoa {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
    
    Pessoa p1 = new Pessoa("Jao", "1234");
    p1.imprime();
    
    Aluno al1 = new Aluno ("Clayton", "55555",33);
    al1.imprime();
    
    Professor prof1 = new Professor ("Tania", "33333", 1500f);
    prof1.imprime();
    
    }
}
