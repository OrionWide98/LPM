/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package exempo_pessoa;

/**
 *
 * @author aluno
 */
public class Pessoa {
    private String nome;
    private String cpf;
    
    public Pessoa (String n, String c)
    {
        this.nome = n;
        this.cpf = c;
    }
    public void imprime()
    {    
        System.out.println("Nome: "+nome);
        System.out.println("CPF:"+cpf);
    }
    public String getNome() {
        return nome;
    }

    /**
     * @param nome the nome to set
     */
    public void setNome(String nome) {
        this.nome = nome;
    }

    /**
     * @return the cpf
     */
    public String getCpf() {
        return cpf;
    }

    /**
     * @param cpf the cpf to set
     */
    public void setCpf(String cpf) {
        this.cpf = cpf;
    }
    
}
