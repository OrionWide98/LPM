/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package aumentafrase;

/**
 *
 * @author aluno
 */
public class AumentaFrase {
    
    
    public static void aumentarLetra() throws NullPointerException{
        String frase = null;
        String novaFrase = null;
        try{
        novaFrase = frase.toUpperCase();
        }
        catch(NullPointerException e){
            
            throw new NullPointerException("Esperado um valor diferente de Null");
        }        
        System.out.println("Frase antiga: "+frase);
        System.out.println("Nova frase: "+novaFrase);
    
    }

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        try{
        aumentarLetra();
        }
        catch(NullPointerException e)
        {
            System.out.println("Método não pode ser exectutado pq a string é null");
            System.out.println(e.toString());
        }
    }
    
}
