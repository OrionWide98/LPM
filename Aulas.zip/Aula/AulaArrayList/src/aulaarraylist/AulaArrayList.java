/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package aulaarraylist;

import java.util.ArrayList;
import java.util.Iterator;

/**
 *
 * @author aluno
 */
public class AulaArrayList {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
       Livro l1 = new Livro();
       Livro l2 = new Livro();
       Revista r1 = new Revista();
       
       ArrayList <Produto> catalogo = new ArrayList ();
       catalogo.add(l1);
       catalogo.add(l2);
       catalogo.add(r1);
     
       Iterator <Produto> it = catalogo.iterator();
       
       while (it.hasNext ())
       {
           Produto p = it.next();
           p.mostradados();
            if (p instanceof Revista)
            {
                System.out.println("====");
               p.mostradados();
            }
       }
               

    }
    
}
