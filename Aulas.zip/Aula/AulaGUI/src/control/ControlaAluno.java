/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package control;

import java.util.ArrayList;
import java.util.Iterator;
import model.Aluno;

/**
 *
 * @author 
 */
public class ControlaAluno {
    
    //ArrayList - atributo
    private ArrayList lista;
    
    //construtor
    public ControlaAluno()
    {
        lista = new ArrayList();
    }
public Aluno adicionnaNaLista(String nome, int idade)
{
    Aluno al1 = new Aluno();
       
    al1.setNome(nome);
    al1.setIdade (idade);
    
    lista.add(al1);
    return al1; 
}

public int somaIdade()
{
    int soma = 0;
    Iterator it = lista.iterator();
    while (it.hasNext())
    {
        Aluno al = (Aluno)it.next();
        soma = soma +al.getIdade();
    }
            return soma;
    
}

        


}
