/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package caixa;

/**
 *
 * @author aluno
 */
public class Caixa {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Poupanca poupanca1 = new Poupanca(2000f);
        Poupanca poupanca2 = new Poupanca(3000f);
        
        Poupanca.modificaTaxaJuros(3f);
        
        System.out.println("Saldo Mensal: R$" + poupanca1.calcularJurosMensal);
    }
    
}
