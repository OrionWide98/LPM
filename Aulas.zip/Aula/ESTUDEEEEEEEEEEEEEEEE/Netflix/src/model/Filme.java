/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

/**
 *
 * @author franc
 */
public class Filme {
    private String nome;
    private int classificacao;
    
    public Filme(String n, int c) throws IllegalArgumentException
    {
        if(c < 0)
        {
            throw new IllegalArgumentException("Valor inválido, os valores esperados são maiores que 0 (zero)");
        }
        
        nome = n;
        if(c>=0 && c<16)
        {
            classificacao = 0;
        }
        if(c>=16 && c<18)
        {
            classificacao = 16;
        }
        if(c>=18)
        {
            classificacao = 18;
        }
    }
    
    /**
     * @return the nome
     */
    public String getNome() {
        return nome;
    }

    /**
     * @param nome the nome to set
     */
    public void setNome(String nome) {
        this.nome = nome;
    }

    /**
     * @return the classificacao
     */
    public int getClassificacao() {
        return classificacao;
    }

    /**
     * @param classificacao the classificacao to set
     */
    public void setClassificacao(int classificacao) {
        this.classificacao = classificacao;
    }
}
