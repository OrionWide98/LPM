/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pessoa;

/**
 *
 * @author franc
 */
public class Professor extends Pessoa{
    private float salario;
    
    /*Construtor*/
    
    public Professor(String nome, String cpf, float salario){
        super(nome,cpf);
        this.salario = salario;
    }
    
    @Override
    public void Imprime(){
        super.Imprime();
        System.out.println("Salario:R$"+salario);
    }
            
    
    /*Gets e Sets*/
    
    public float getSalario() {
        return salario;
    }
     
    public void setSalario(float salario) {
        this.salario = salario;
    }
}
