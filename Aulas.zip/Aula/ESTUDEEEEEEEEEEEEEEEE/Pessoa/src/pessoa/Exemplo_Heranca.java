/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pessoa;

/**
 *
 * @author franc
 */
public class Exemplo_Heranca {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Pessoa p1 = new Pessoa("João", "1234");
        p1.Imprime();
        
        Aluno al1 = new Aluno("Clayton", "5555555", 33);
        al1.Imprime();
        
        Professor prof1 = new Professor("Tânia", "33333333", 1500.60f);
        prof1.Imprime();
    }
    
}
