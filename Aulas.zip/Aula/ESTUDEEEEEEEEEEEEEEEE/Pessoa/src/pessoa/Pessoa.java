/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pessoa;

/**
 *
 * @author franc
 */
public class Pessoa {
    private String nome;
    private String cpf;
    
    /*Gets e Sets*/
    
    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getCpf() {
        return cpf;
    }

    public void setCpf(String cpf) {
        this.cpf = cpf;
    }
    
    /*Contrutor*/
    
    public Pessoa(String n, String c){
        this.nome = n;
        this.cpf = c;
    }
    
    public void Imprime(){
        System.out.println("Nome:"+nome);
        System.out.println("CPF:"+cpf);
    }
}
