/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package testaexcecoes3;

/**
 *
 * @author franc
 */
public class CalculoMatematico {
 
    public float divisao(int a, int b)
    {
        float div = 0;
        try
        {
            div = a/b;
        }
        catch(ArithmeticException e)
        {
            System.out.println("Não é possível dividir por 0.");
        }
        return div;
    }
    
}
