/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package exercicioum;

/**
 *
 * @author aluno
 */
public class ExercicioUm {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        Funcionario Func1 = new Funcionario("João", 1250.50f);
        Funcionario Func2 = new Funcionario("Francisco","Silva", -5000.00f);
        
        //Funcionario 1
        
        System.out.println("Funcionário: " + Func1.getNome() + " " + Func1.getSobrenome());
        System.out.printf("Salário: R$%.2f\n", Func1.getSalario());
        System.out.println("Recebeu um aumento de 10%");
        Func1.Aumento();
        System.out.printf("Salário atual: R$%.2f\n", Func1.getSalario());
    
        System.out.println("_____________________________________");
        //Funcionario 2
        
        System.out.println("Funcionário: " + Func2.getNome() + " " + Func2.getSobrenome());
        System.out.printf("Salário: R$%.2f\n", Func2.getSalario());
        Func2.Aumento();
        System.out.printf("Salário atual: R$%.2f\n", Func2.getSalario());
    }
    
}
