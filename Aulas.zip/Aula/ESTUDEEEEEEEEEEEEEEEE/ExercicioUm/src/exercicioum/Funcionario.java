/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package exercicioum;

/**
 *Criação da Classe Funcionário
 * @author Francisco
 */
public class Funcionario { 
    //Atributos
    private String nome;
    private String sobrenome;
    private float salario;
    
    //Construtor Default
    public Funcionario() {
        nome = "";
        sobrenome = "";
        salario = 0f;
    }
    
    //Gets e Sets
    public String getNome() {
        return nome;
    }

    
    public void setNome(String nome) {
        this.nome = nome;
    }

    
    public String getSobrenome() {
        return sobrenome;
    }

    
    public void setSobrenome(String sobrenome) {
        this.sobrenome = sobrenome;
    }

    
    public float getSalario() {
        return salario;
    }

    public void setSalario(float salario) {
        this.salario = salario;
    }
    
    //Sobrecarga
    public Funcionario(String nome, String sobrenome, float salario) {
        this.nome = nome;
        this.sobrenome = sobrenome;
        if (salario < 0){
            this.salario = 0;
        } else this.salario = salario;
    }
    
    public Funcionario(String nome, String sobrenome) {
        this.nome = nome;
        this.salario = 0;
        this.sobrenome = sobrenome;
    }
    
    public Funcionario(String nome, float salario) {
        this.nome = nome;
        this.sobrenome = "";
        if (salario < 0){
            this.salario = 0;
        } else this.salario = salario;
    }
    
    public Funcionario(float salario) {
        this.nome = this.sobrenome = "";
        this.salario = salario;
        if (salario < 0){
            this.salario = 0;
        } else this.salario = salario;
    }
    
    public Funcionario(String nome) {
        this.nome = nome;
        this.sobrenome = "";
        this.salario = 0f;
    }
  
    //Métodos
    public void Aumento() {
        if(salario == 0){
            System.out.println("Salário não é válido!");
        } else this.salario *= 1.1;
    }
}
