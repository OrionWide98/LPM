/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package testapagamento;

/**
 *
 * @author franc
 */
public interface TipoPagamento {
    
    public int getDiasFaturamento();
    
    public double getPorcFinacPaga();
    
}
