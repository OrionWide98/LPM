/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package aula_interface;

/**
 *
 * @author franc
 */
public class Ferrari implements Carro, ItemCaro{

    @Override
    public void abrirPorta() {
        System.out.println("Ferrari abre suas portas");
    }

    @Override
    public void virarEsquerda() {
        System.out.println("Ferrari vira a esquerda");
    }

    @Override
    public void virarDireita() {
        System.out.println("Ferrari vira a direita");
    }

    @Override
    public void acelerar() {
        System.out.println("Ferrari liga o turbo");
    }

    @Override
    public double getPreco() {
        return (1500000);
    }
}
