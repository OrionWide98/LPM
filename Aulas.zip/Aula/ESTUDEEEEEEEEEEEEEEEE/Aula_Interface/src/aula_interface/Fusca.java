/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package aula_interface;

/**
 *
 * @author franc
 */
public class Fusca implements Carro, ItemCaro{

    @Override
    public void abrirPorta() {
        System.out.println("Porta do fusca caiu");
    }

    @Override
    public void virarEsquerda() {
        System.out.println("Fusca travou na viragem");
    }

    @Override
    public void virarDireita() {
        System.out.println("Fusca queimou o motor");
    }

    @Override
    public void acelerar() {
        System.out.println("Fusca morreu");
    }

    @Override
    public double getPreco() {
        double imposto = 500;
        return (76000+imposto);
    }
}
