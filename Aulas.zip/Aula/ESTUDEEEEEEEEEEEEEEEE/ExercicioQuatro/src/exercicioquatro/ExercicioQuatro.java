/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package exercicioquatro;

/**
 *
 * @author franc
 */
public class ExercicioQuatro {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Estoque estoque1 = new Estoque("Impressora", 13, 6);
        Estoque estoque2 = new Estoque("Monitor", 11, 13);
        Estoque estoque3 = new Estoque("Mouse", 6, 2);
        
        System.out.println("INÍCIO DE ESTOQUE");
        System.out.println(estoque1.mostra() + "\n");
        System.out.println(estoque2.mostra() + "\n");
        System.out.println(estoque3.mostra() + "\n");
        
        estoque1.baixarEstoque(5);
        estoque2.reporEstoque(7);
        estoque3.baixarEstoque(4);
        
        System.out.println("ALTERAÇÕES DE ESTOQUE");
        System.out.println(estoque1.mostra() + "\n");
        System.out.println(estoque2.mostra() + "\n");
        System.out.println(estoque3.mostra() + "\n");
        
        System.out.println("REPOSIÇÕES");
        System.out.println("Estoque 1: " + estoque1.precisaRepor());
        System.out.println("Estoque 2: " + estoque2.precisaRepor());
        System.out.println("Estoque 3: " + estoque3.precisaRepor());
        
    }
    
}
