/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package exercicioquatro;

/**
 *
 * @author franc
 */
public class Estoque {

    private String nome;
    private int qntAtual;
    private int qntMinima;
    
    //Gets e Sets
    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public int getQntAtual() {
        return qntAtual;
    }

    public void setQntAtual(int qntAtual) {
        this.qntAtual = qntAtual;
    }

    public int getQntMinima() {
        return qntMinima;
    }

    public void setQntMinima(int qntMinima) {
        this.qntMinima = qntMinima;
    }
    
    //Construtores
    public Estoque(){
        nome = " ";
        qntAtual = 0;
        qntMinima = 0;
    }
    
    public Estoque(String n, int qA, int qM){
        nome = n;
        if(qA<0){
            qntAtual = 0;
        } else qntAtual = qA;
        
        if(qM<0){
            qntMinima = 0;
        } else qntMinima = qM;
    }
    
    //Metodos
    public void reporEstoque(int qnt){
        qntAtual += qnt; 
    }
    
    public void baixarEstoque(int qnt){
        if (qntAtual == 0){
            System.out.println("Estoque vazio.");
        } else if (qntAtual < qnt){
            System.out.println("Não é possível tirar toda essa quantidade");
        } else qntAtual -= qnt;
    }
    
    public String mostra(){
        String msg = ("Produto: " + nome + "\nQuantidade Mínima: " + qntMinima + "\nQuantidade Atual: " + qntAtual);
        return msg;
    }
    
    public String precisaRepor(){
        if(qntAtual <= qntMinima){
            int a = qntMinima - qntAtual + 1;
            return ("Precisa Repor (" + a + " unidade(s) no mínimo).");
        } else return "Não Precisa Repor";
    }
}
