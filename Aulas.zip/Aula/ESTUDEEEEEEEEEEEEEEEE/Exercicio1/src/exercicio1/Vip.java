/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package exercicio1;

/**
 *
 * @author franc
 */
public class Vip extends Ingresso{
    private final float valorAd;
    
    public Vip(float v, float vA)
    {
        super(v + vA);
        valorAd = vA;
    }
    
    @Override
    public void imprimeValor()
    {
        System.out.printf("Valor Ingresso VIP: R$%.2f",(getValor() + valorAd));
    }
}
