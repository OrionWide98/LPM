/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package polimorfismo;


/**
 *
 * @author franc
 */
public class Polimorfismo {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Animal clayton = new Cachorro();
        Animal jao = new Cavalo();
        Animal francisco = new Preguica();
        
        clayton.setIdade(35);
        clayton.setNome("Claytinho");
        jao.setIdade(18);
        jao.setNome("João");
        francisco.setIdade(16);
        francisco.setNome("Francisco");
        
        System.out.println("Cachorro");
        clayton.emitirSom();
        Cachorro a = (Cachorro) clayton;
        a.correr();
        
        System.out.println("\nCavalo");
        jao.emitirSom();
        Cavalo b = (Cavalo) jao;
        b.correr();
        
        System.out.println("\nPreguiça");
        francisco.emitirSom();
        Preguica c = (Preguica) francisco;
        c.subir();
    }
}
