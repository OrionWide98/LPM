/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package criaobjeto;

/**
 *
 * @author aluno
 */
public class Caneta {
    //Atributos
    private String cor;
    private String marca;
    private float ponta;
    private boolean cheia;
    private boolean tampada;
    
    //Metodos
    public void escreva() {
        if (cheia) {
            if (tampada) {
                System.out.println("Destampe primeiro");
            }
            else {
                System.out.println("Escrevendo");
            }
        }
        else {
            System.out.println("Caneta sem tinta");
        }
    }
    
    public void destampar() {
        this.tampada = false;
    }
    
    public void tampar() {
        this.tampada = true;
    }
    
    public void tinta() {
        if (cheia) {
            System.out.println("Tem tinta");
        }
        else {
            System.out.println("Troque de caneta");
        }
    }
    
}
