/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package criaobjeto;

/**
 *
 * @author aluno
 */
public class Carro {
    //atributos
    private String cor;
    private float motor;
    private String modelo;
    
    public String getCtor()
    {
        return cor;
    }
    
    public float getMotor()
    {
        return motor;
    }
    
    public String getModelo ()
    {
    
    }
    //metodos
    public void acelerar () 
    {
        System.out.println("Acelerando rrrrrrrrrrrrrrrrrraaaaaaaaaaaaaaaaaaaaaaaampá");
    }
    
    public void parar ()
    {
        System.out.println("Parando rrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrpow");
    }
            
}
