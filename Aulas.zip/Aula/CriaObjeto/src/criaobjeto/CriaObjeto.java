/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package criaobjeto;

/**
 *
 * @author aluno
 */
public class CriaObjeto {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        //CLASSE CARRO
        
        Carro x = new Carro();
        x.cor = "prata";
        x.modelo = "celta";
        x.motor = 1.0f;
        x.acelerar();
       
        Carro y = new Carro();
        y.cor = "branco";
        y.modelo = "Gol";
        y.motor = 2.0f;
        y.acelerar();
        y.parar();
        
        Carro z = new Carro();
        z.cor = "preto";
        z.modelo = "Fusca";
        z.motor = 3.0f;
        z.parar();
        
        
        //CLASSE CANETA 
        
        /*Caneta a = new Caneta();
        a.cor = "azul";
        a.marca = "bic";
        a.ponta = 1.0f;
        a.cheia = true;
        a.tampada= false;
        a.tinta();
        a.escreva();
        
        Caneta b = new Caneta();
        b.cor = "begerosa";
        b.marca = "pilot";
        b.ponta = 2.0f;
        b.cheia = false;
        b.tampada = true;
        b.tampar();
        b.destampar();
        b.tinta();
        a.escreva();
        */
    }
    
}
