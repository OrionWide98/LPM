/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package aulaabstrata;

/**
 *
 * @author aluno
 */
public class AulaAbstrata {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        //Pessoa p1= new Pessoa();
        Aluno al1 = new Aluno();
        al1.mostraDados();
        al1.testaDados();
    
        Professor prof1 = new Professor();
        prof1.mostraDados();
        prof1.testaDados();
        
        Pessoa p1 = new Aluno();
        p1.mostraDados();
        p1.testaDados();
    }
    
}
