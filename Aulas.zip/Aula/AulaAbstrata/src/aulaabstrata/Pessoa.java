/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package aulaabstrata;

/**
 *
 * @author aluno
 */
public abstract class Pessoa {
    
//atributo
    private int idade;
            
            
    //método abstrato
    public  abstract void mostraDados(); 
    
    
    //método concreto
    public final void testaDados()
    {
        System.out.println("TESTANDO DADOS DA PESSOA");
    }
}
