/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package declarandovariaveis;

import java.util.Scanner;

/**
 *
 * @author aluno
 */
public class DeclarandoVariaveis {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        int idade;
        float peso;
        String letra;
        String nome;
        
        Scanner teclado = new Scanner(System.in);
        
        System.out.println("Digite seu nome: ");
        nome = teclado.nextLine();
        System.out.println("Digite sua idade: ");
        idade = teclado.nextInt();
        System.out.println("Digite seu peso: ");
        peso = teclado.nextFloat();
        System.out.println("Digite sua letra favorita: ");
        letra = teclado.next();
        
        
        
        System.out.println("O aluno " + nome +  " tem " + idade + " anos de idade e pesa " + peso + "kg" ) ;
        System.out.println("Letra favorita: " + letra);
    }
    
}
